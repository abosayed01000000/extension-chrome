# Summary

### Steps to reproduce
(Please provide detail steps).   

### What is the current bug behaviour?
(What actually happens).

### What is the expected correct behaviour?
(What you should see instead).

### Relevant logs and/or screenshots

### Possible fixes suggested remediation

### Assignees and labels
( please add labels as applicable )    
 ~bug  ~confirmed    
 ~feature ~suggestion    
 ~Windows  ~Linux  ~OSX    
 ~Emergency ~Major ~Minor    
%"milestone"    
/cc @Dev /assign @tester  
- [ ] Patched
- [ ] Verified patch
