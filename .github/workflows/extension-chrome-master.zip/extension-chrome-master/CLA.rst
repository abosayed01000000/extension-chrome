
# Contributor agreement

By contributing any improvement, modification, or change to this project, I hereby certify that:

(a) The contribution was authored or created in whole or in part by me and I have the full and unrestricted ownership right and title to submit the contribution under the MIT license; or

(b) The contribution is based upon previously authored work that, to the best of my knowledge, is licensed appropriately under an open source license and I have the full and unrestricted right under that open source license to submit that work with modifications, whether created in whole or in part by me, under the MIT license; or

(c) The contribution was lawfully provided to me by a licensed third-party who certified (a), (b) or (c) and I have not modified the contribution.

I understand and agree that the contents of this project and the contents of this contribution are considered to be part of the public record and that a record of the contribution (including all personal information I submit with it) shall be maintained indefinitely and may be redistributed to third-parties consistent with this terms of this project or the open source license(s) involved.