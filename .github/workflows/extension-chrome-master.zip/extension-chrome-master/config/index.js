/* eslint global-require: 0 */
module.exports = {
  pkg: require('../package.json'),
  oneskyExport: require('./oneskyexport'),
  oneskyImport: require('./oneskyimport'),
};
