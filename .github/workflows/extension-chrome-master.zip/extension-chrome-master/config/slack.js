module.exports = {
  hook: process.env.SLACK_HOOK // eslint-disable-line no-process-env
};
