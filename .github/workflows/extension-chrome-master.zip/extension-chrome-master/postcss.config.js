module.exports = {
  plugins: [
    // eslint-disable-next-line
    require('precss'),
    // eslint-disable-next-line
    require('autoprefixer'),
  ],
};
