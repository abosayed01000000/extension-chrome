type StorageType = 'localStorage' | 'memoryStorage';

export { StorageType };
