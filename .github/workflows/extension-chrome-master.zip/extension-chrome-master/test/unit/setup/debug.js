beforeEach(() => {
  window.debug = jest.fn().mockName('debug');
});
