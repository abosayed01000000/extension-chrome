# Webpack

The extension uses webpack for its build system to generate the distributables.

## Plugins

A number of plugins have been developed specifically for the extensions, as open source plugins targeting web extensions seemed to be lacking at the time of conversion. At the time of writing, most of them are not something of necessary quality for open source consideration, but all should be functional and reliable under normal circumstances.
